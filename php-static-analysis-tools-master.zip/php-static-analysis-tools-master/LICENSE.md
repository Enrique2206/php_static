Content is available under the Creative Commons 3.0 License.
https://creativecommons.org/licenses/by/3.0/