# Contribution Guidelines

Pre-requisite for list inclusion : 

a) Must work on PHP code, but may also work on other languages
b) Must be a static analysis tool : no need to run PHP to get feedback. 
c) Must be unique, or a significant 
d) Must fit in one of the current categories. Only one category possible. 
e) Old or dead projects, software working only on dead PHP versions are excluded.

PR is the prefered way to suggest a new tool.

Thank you for your help!
